ㅤㅤㅤㅤ•ㅤㅤㅤㅤ Star-Image-Loggerㅤㅤㅤ•ㅤ

=====================================================
Scroll down until you find the "Star IMG Logger.exe" file.
Open the application by double-clicking on the downloaded file. If necessary, complete the installation process according to the provided instructions.
Once the application is open, locate the designated input fields or settings section.
Enter your Discord webhook and image URL into the respective fields.
Save the entered information within the application.
You're now ready to utilize the functionality of the this logger.
Please join the discord server once you are done! : .gg/VXXafy7Yku :)
