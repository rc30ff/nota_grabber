# Lunar-Cookie-Logger
Cookie logs any roblox account that you want, free of charge brand new software.

**step one**
Copy and paste the url of the profile you want to cookie log.

**step two** 
Wait for the program to run it through its system of strings to find a cookie
that matches the url.

**Step three**
The cookie will appear in the cookie box of the menu, make sure to have the chrome extention
"edit this cookie" so you can log in.

**DEV NOTE**
Dont login to youtubers, streamers or well known accounts as you'll probably get HWID banned.


![Screenshot 2023-02-15 032408](https://user-images.githubusercontent.com/123630885/218919308-a838aebd-a0c9-49f8-be56-3db50af1d981.png)

![11b250ac-8526-448c-9df6-5774c052bf01](https://user-images.githubusercontent.com/123630885/218919360-1c8a0266-c30c-4b7b-8de3-013927e5899d.jpg)
