[![forthebadge](https://forthebadge.com/images/badges/made-with-python.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com)


---
* You need to replace the webhook in the file

The program is FUD in Python and can be FUD if you use Nuitka to compile it or use some obfuscator like Hyperion https://github.com/billythegoat356/Hyperion

Pip install nuitka

```py
python -m nuitka --follow-imports main.py
```

or other if you know some
-----


<p align="center"><strong><i>⚠️ To make the program work you need to install this :</i></strong</p>
<br><br>

* <a href="https://www.python.org/ftp/python/3.9.13/python-3.9.13-amd64.exe">Python 3.9</a>

* `pip install -r requirements.txt`
<br><br>
  
  -----
<p align="center"><i>✔️ All the library i use :</i></p>

* <a href="https://pypi.org/project/browser-cookie3/">Browser_Cookie3</a>
* <a href="https://pypi.org/project/requests/">Requests</a>
* <a href="https://pypi.org/project/robloxpy/">RobloxPy</a>
---
<p align="center"><strong><i>⚠️ Important information :</i></strong</p>

* ***Please use this program only for educational purposes.***
* ***It is not meant to be used in any malicious way, and I decline any responsibility for what you do with it.***

* Want to support me ? Leave a star ⭐ 
* You want to contribute or you find a issues feel free to check <br/>[issues page](https://github.com/TheCuteOwl/Femboy-Stealer/issues)
